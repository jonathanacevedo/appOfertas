export * from './personas.service';
import { PersonasService } from './personas.service';
export const APIS = [PersonasService];
