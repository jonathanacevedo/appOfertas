package orquestador.routes.persona;

public class listarPersonaEstado {

}
