package orquestador.routes.negocio;

public class listarNegocioTipo {

}
