package orquestador.routes.persona;

public class listarPersonaRol {

}
