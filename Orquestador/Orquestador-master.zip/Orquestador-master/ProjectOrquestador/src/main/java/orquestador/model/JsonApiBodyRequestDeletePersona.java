package orquestador.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import orquestador.model.DeleteRequestPersona;

import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * JsonApiBodyRequestDeletePersona
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-08-17T14:53:38.878-05:00")

public class JsonApiBodyRequestDeletePersona   {
  @JsonProperty("persona")
  @Valid
  private List<DeleteRequestPersona> persona = new ArrayList<DeleteRequestPersona>();

  public JsonApiBodyRequestDeletePersona persona(List<DeleteRequestPersona> persona) {
    this.persona = persona;
    return this;
  }

  public JsonApiBodyRequestDeletePersona addPersonaItem(DeleteRequestPersona personaItem) {
    this.persona.add(personaItem);
    return this;
  }

  /**
   * Get persona
   * @return persona
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public List<DeleteRequestPersona> getPersona() {
    return persona;
  }

  public void setPersona(List<DeleteRequestPersona> persona) {
    this.persona = persona;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    JsonApiBodyRequestDeletePersona jsonApiBodyRequestDeletePersona = (JsonApiBodyRequestDeletePersona) o;
    return Objects.equals(this.persona, jsonApiBodyRequestDeletePersona.persona);
  }

  @Override
  public int hashCode() {
    return Objects.hash(persona);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class JsonApiBodyRequestDeletePersona {\n");
    
    sb.append("    persona: ").append(toIndentedString(persona)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

